#ifndef HOST_H
#define HOST_H

struct owner_host{
	unsigned long ip;
	unsigned long port;
};

#endif
