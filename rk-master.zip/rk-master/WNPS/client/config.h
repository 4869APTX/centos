#ifndef CONFIG_H
#define CONFIG_H

#define ENCRYPT			0

#define DEFAULT_INTERFACE       "eth0"
#define TCP_SHELL_KEY           "@wztshell"

#define DEFAULT_IP 192.168.130.130
#define DEFAULT_PORT            8899

#define home            	"/"

#endif

