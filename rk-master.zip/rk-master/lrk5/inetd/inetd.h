
int daemon(int, int);
